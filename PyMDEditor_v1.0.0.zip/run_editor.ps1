﻿# PyMD Editor 启动脚本
Set-Location -LiteralPath "$PSScriptRoot\src"
& "$PSScriptRoot\.venv\Scripts\python.exe" -m pymd_editor.main
